import styles from '../styles/Home.module.css'
// import "./styles.css"
import Layout from '../components/Layout'

export default function Home() {
  return (
    <div>
      <Layout children={undefined} />
    </div>
  )
}